{
    "inherits": "trollian2.5",

    "convo": {
        "style": "background-color: #e5000f;border:2px solid #780000; font-family: 'Arial';",


        "textarea": {
            "style": "background: #2d2b27; color: white; font-size: 14px;font:bold; border:2px solid #ffa4a4;text-align:center; margin-right:10px; margin-left:10px;font-family: 'Arial'"
        },

        "input": {
            "style": "background: #2d2b27; color: white; border:2px solid #ffa4a4;margin-top:5px; margin-right:10px; margin-left:10px; font-size: 12px;"
        }
    },


    "memos": {
        "style": "background-color: #e5000f;border:2px solid #780000; font-family: 'Arial';",
        "label": {
            "style": "margin-bottom: 21px;background: #ffa4a4; color: black; border:0px; font-size: 14px;"
        },
        "textarea": {
            "style": "background: #2d2b27; color: white; font-size: 14px;font:bold; border:2px solid #ffa4a4;text-align:center; margin-right:10px; margin-left:10px;font-family: 'Arial'"
        },
        "userlist": {
            "style": "border:2px solid #780000; background: #3a3833; color:white; font: bold;font-family: 'Courier';selection-background-color:#646464; font-size: 12px;  margin-left:0px; margin-right:10px;"
        },
        "input": {
            "style": "background: #2d2b27; color: white; border:2px solid #ffa4a4;margin-top:5px; margin-right:10px; margin-left:10px; font-size: 12px;"
        },

        "time": {
            "text": {
                "style": " border: 2px solid #780000; background: #780000; font-size: 12px; margin-top: 5px; margin-right: 5px; margin-left: 5px; font-family:'Arial';font:bold;"
            },
            "buttons": {
                "style": "color: black; font: bold; border: 2px solid #780000; font: bold; font-size: 12px; background: #e5000f; margin-top: 5px; margin-right: 5px; margin-left: 5px; padding: 2px; width: 50px;"
            }
        }
    }
}