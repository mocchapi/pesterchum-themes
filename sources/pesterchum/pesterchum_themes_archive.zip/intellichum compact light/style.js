{
	"memos": {
		"systemMsgColor": "#ff141517",
		"userlist": {
			"width": 205,
			"style": "border-color: #ff5a6372; border-width: 3px; color: #ff141517; background-color: #ffebeae8; border-style: solid; margin-right: 11px; "
		},
		"input": {
			"style": "border-color: #ff5a6372; border-width: 3px; color: #ff141517; background-color: #ffebeae8; border-style: solid; margin: 0px 11px; "
		},
		"textarea": {
			"style": "border-color: #ff5a6372; border-width: 3px; color: #ff141517; background-color: #ffebeae8; border-style: solid; margin-left: 11px; margin-right: 11px; "
		}
	},
	"convo": {
		"systemMsgColor": "#ff141517",
		"input": {
			"style": "border-color: #ff5a6372; border-width: 3px; color: #ff141517; background-color: #ffebeae8; border-style: solid; margin: 0px 11px; "
		},
		"textarea": {
			"style": "border-color: #ff5a6372; border-width: 3px; color: #ff141517; background-color: #ffebeae8; border-style: solid; margin-left: 11px; margin-right: 11px; "
		}
	},
	"inherits": "intellichum compact"
}