                          _           _     _      _____                   _             
     /\                  | |         (_)   | |    / ____|                 (_)            
    /  \   _ __ __ _  ___| |__  _ __  _  __| |___| |     _ __ ___  ___ ___ _ _ __   __ _ 
   / /\ \ | '__/ _` |/ __| '_ \| '_ \| |/ _` / __| |    | '__/ _ \/ __/ __| | '_ \ / _` |
  / ____ \| | | (_| | (__| | | | | | | | (_| \__ \ |____| | | (_) \__ \__ \ | | | | (_| |
 /_/    \_\_|  \__,_|\___|_| |_|_| |_|_|\__,_|___/\_____|_|  \___/|___/___/_|_| |_|\__, |
                                                                                    __/ |
                                                                                   |___/ 
   A theme based on Animal Crossing: Wild World (nds)
    by (lis)anne / mocha                january 2025



## Made with pesterchum theme editor 2000 :)
https://mocchapi.itch.io/pesterchum-theme-editor-2000

## attribution:
- The main background & item_ring were taken directly from the game with DeSmuMe
- The icon was taken from The Spriters Resource, submitted by Alxala:
	- https://www.spriters-resource.com/ds_dsi/animalxingwildworld/sheet/225698/
- The mood/expression icons were taken from Nookipedia.com:
	- https://nookipedia.com/wiki/Reaction#In_Wild_World

- The open/close pm sound was taken directly from the game with DeSmuMe
- The namealert & memo sound were taken from The sounds resource, submitted by Previous:
	- https://www.sounds-resource.com/ds_dsi/acww/sound/1733/
	- (memo is `488.wav`, namealert is `406.wav`)

- The font is by "David" on DaFont, who seems to have created it from spritesheets
	- https://www.dafont.com/animal-crossing-wild-world.font
	- https://www.dafont.com/david-fens.d5063